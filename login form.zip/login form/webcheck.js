var objpeople = [
    {
        username:"sam",
        password:"codify"
    },
    {
        username:"clinton",
        password:"academy"
    },
    {
        username:"john",
        password:"forever"
    }
]

function getInfo() {
    var username = document.getElementById("username").Value
    var password = document.getElementById("password").value

    for(i = 0; i < objpeople.length; i++) {
        if(username == objpeople[i].username && password == objpeople[i].password) {
            console.log(username + "is logged in!!!")
         
        }
        
        else {
            console.log("incorrect username or password")
            document.location.href = "manager.html"  
        }
      }
    }